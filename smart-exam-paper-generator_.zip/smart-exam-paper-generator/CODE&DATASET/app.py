import json
import re
import random
import pickle
import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer

import dash
from dash import dcc, html, Input, Output, State
import dash_bootstrap_components as dbc

# ── NLTK Downloads ────────────────────────────────────────────────────────────
for pkg in ['punkt', 'stopwords', 'wordnet', 'omw-1.4', 'punkt_tab']:
    nltk.download(pkg, quiet=True)

# ── NLP Helpers (same as notebook) ───────────────────────────────────────────
lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))

def clean_text(text):
    if not isinstance(text, str):
        return ''
    text = text.lower()
    text = re.sub(r'[^a-z0-9\s]', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()

# ── Load Saved Models & Data ──────────────────────────────────────────────────
print("Loading models and data...")

with open('D:\\sahithi\\a\\metadata.json') as f:
    metadata = json.load(f)

with open('D:\\sahithi\\a\\best_model.pkl', 'rb') as f:
    best_model = pickle.load(f)

all_models = {}
for name, fname in metadata['model_files'].items():
    with open(f'D:\\sahithi\\a\\logistic_regression.pkl', 'rb') as f:
        all_models[name] = pickle.load(f)

df = pd.read_pickle('D:\\sahithi\\a\\df_preprocessed.pkl')

cop_map     = {int(k): v for k, v in metadata['cop_map'].items()}
subjects    = metadata['subjects']
topics      = metadata['topics']
best_model_name = metadata['best_model_name']

ALL = 'ALL'

print(f"✅ Loaded {len(df)} records | Best model: {best_model_name}")

# ── Predict Answer Helper ─────────────────────────────────────────────────────
def predict_answer(question_text, model_name=None):
    model = all_models.get(model_name, best_model)
    cleaned = clean_text(question_text)
    pred = model.predict([cleaned])[0]
    return metadata['cop_map'][str(pred)]

# ── Option Colors ─────────────────────────────────────────────────────────────
OPTION_COLORS = {
    'A': '#3b82f6',
    'B': '#10b981',
    'C': '#f59e0b',
    'D': '#ef4444',
}

# ── MCQ Card Builder ──────────────────────────────────────────────────────────
def make_mcq_card(idx, row, show_answers, show_prediction, selected_model):
    option_labels = ['A', 'B', 'C', 'D']
    option_keys   = ['opa', 'opb', 'opc', 'opd']
    correct       = row.get('correct_label', '')
    predicted     = predict_answer(row['question'], selected_model) if show_prediction else None

    option_items = []
    for label, key in zip(option_labels, option_keys):
        opt_text   = row.get(key, '')
        is_correct = show_answers and label == correct
        is_predicted = show_prediction and label == predicted

        if is_correct and is_predicted:
            bg    = '#d1fae5'
            border= '#10b981'
            color = '#065f46'
        elif is_correct:
            bg    = '#d1fae5'
            border= '#10b981'
            color = '#065f46'
        elif is_predicted:
            bg    = '#eff6ff'
            border= '#3b82f6'
            color = '#1e40af'
        else:
            bg    = '#f8fafc'
            border= OPTION_COLORS[label]
            color = '#1e293b'

        tags = []
        if is_correct:
            tags.append(html.Span('✓ Correct', style={
                'background': '#10b981', 'color': 'white',
                'fontSize': '10px', 'padding': '1px 7px',
                'borderRadius': '10px', 'marginLeft': '8px', 'fontWeight': '700'
            }))
        if is_predicted and not is_correct:
            tags.append(html.Span('🤖 Predicted', style={
                'background': '#3b82f6', 'color': 'white',
                'fontSize': '10px', 'padding': '1px 7px',
                'borderRadius': '10px', 'marginLeft': '8px', 'fontWeight': '700'
            }))
        if is_predicted and is_correct:
            tags.append(html.Span('🤖 Predicted', style={
                'background': '#3b82f6', 'color': 'white',
                'fontSize': '10px', 'padding': '1px 7px',
                'borderRadius': '10px', 'marginLeft': '8px', 'fontWeight': '700'
            }))

        badge = html.Span(label, style={
            'background': OPTION_COLORS[label],
            'color': 'white',
            'borderRadius': '50%',
            'width': '26px', 'height': '26px',
            'display': 'inline-flex',
            'alignItems': 'center',
            'justifyContent': 'center',
            'fontWeight': '700',
            'fontSize': '12px',
            'flexShrink': '0',
        })

        option_items.append(html.Div(
            [badge, html.Span(str(opt_text), style={'flex': '1'})] + tags,
            style={
                'padding': '8px 14px',
                'marginBottom': '6px',
                'borderRadius': '8px',
                'fontSize': '14px',
                'border': f'1.5px solid {border}',
                'backgroundColor': bg,
                'color': color,
                'fontWeight': '600' if (is_correct or is_predicted) else '400',
                'display': 'flex',
                'alignItems': 'center',
                'gap': '10px',
            }
        ))

    # Answer + Prediction summary
    footer_items = []
    if show_answers and correct:
        footer_items.append(html.Span([
            html.Span('✅ Correct: ', style={'fontWeight': '600', 'color': '#065f46'}),
            html.Span(f'Option {correct}', style={
                'background': OPTION_COLORS.get(correct, '#10b981'),
                'color': 'white', 'padding': '2px 10px',
                'borderRadius': '12px', 'fontWeight': '700', 'fontSize': '12px',
            }),
        ], style={'marginRight': '14px'}))

    if show_prediction and predicted:
        match = '✅' if predicted == correct else '❌'
        footer_items.append(html.Span([
            html.Span(f'🤖 Model Predicted: ', style={'fontWeight': '600', 'color': '#1e40af'}),
            html.Span(f'Option {predicted}', style={
                'background': OPTION_COLORS.get(predicted, '#3b82f6'),
                'color': 'white', 'padding': '2px 10px',
                'borderRadius': '12px', 'fontWeight': '700', 'fontSize': '12px',
            }),
            html.Span(f' {match}', style={'marginLeft': '6px', 'fontSize': '13px'}),
        ]))

    footer = html.Div(footer_items, style={'marginTop': '10px', 'display': 'flex', 'flexWrap': 'wrap', 'gap': '6px'}) if footer_items else html.Div()

    return dbc.Card(
        dbc.CardBody([
            html.Div([
                html.Span(f'Q{idx}', style={
                    'background': '#1e40af', 'color': 'white',
                    'borderRadius': '8px', 'padding': '2px 10px',
                    'fontWeight': '700', 'fontSize': '13px',
                    'marginRight': '10px', 'flexShrink': '0',
                }),
                html.Span(str(row['question']), style={
                    'fontWeight': '600', 'fontSize': '15px', 'color': '#0f172a',
                }),
            ], style={'marginBottom': '12px', 'display': 'flex', 'alignItems': 'flex-start'}),

            html.Div(option_items),
            footer,

            html.Div([
                html.Span('📚 ', style={'fontSize': '12px'}),
                html.Span(f"{row['subject_name']} › {row['topic_name']}",
                          style={'fontSize': '12px', 'color': '#94a3b8'})
            ], style={'marginTop': '10px'}),
        ]),
        style={
            'marginBottom': '16px',
            'border': '1px solid #e2e8f0',
            'borderRadius': '12px',
            'boxShadow': '0 1px 4px rgba(0,0,0,0.06)',
            'background': 'white',
        }
    )

# ── App Layout ────────────────────────────────────────────────────────────────
app = dash.Dash(
    __name__,
    external_stylesheets=[dbc.themes.BOOTSTRAP],
    title='MCQ Question Generator'
)

app.layout = dbc.Container([

    # ── Header ────────────────────────────────────────────────────────────────
    dbc.Row(dbc.Col(html.Div([
        html.H2('🎓 MCQ Question Generator', style={
            'color': '#1e3a8a', 'fontWeight': '800', 'marginBottom': '4px'
        }),
        html.P('Medical MCQ Practice — NLP Powered | Filter by Subject & Topic',
               style={'color': '#64748b', 'marginBottom': '0'}),
    ], style={'padding': '24px 0 16px 0'}))),

    # ── Controls Card ─────────────────────────────────────────────────────────
    dbc.Card([
        dbc.CardBody([

            dbc.Row([
                dbc.Col([
                    html.Label('📘 Subject', style={'fontWeight': '600', 'color': '#374151', 'marginBottom': '6px', 'display': 'block'}),
                    dcc.Dropdown(
                        id='subject-dropdown',
                        options=[{'label': s, 'value': s} for s in [ALL] + subjects],
                        value=ALL,
                        clearable=False,
                        style={'borderRadius': '8px'},
                    ),
                ], md=4),

                dbc.Col([
                    html.Label('📗 Topic', style={'fontWeight': '600', 'color': '#374151', 'marginBottom': '6px', 'display': 'block'}),
                    dcc.Dropdown(
                        id='topic-dropdown',
                        options=[{'label': t, 'value': t} for t in [ALL] + topics],
                        value=ALL,
                        clearable=False,
                        style={'borderRadius': '8px'},
                    ),
                ], md=4),

                dbc.Col([
                    html.Label('🤖 ML Model', style={'fontWeight': '600', 'color': '#374151', 'marginBottom': '6px', 'display': 'block'}),
                    dcc.Dropdown(
                        id='model-dropdown',
                        options=[
                            {'label': f'⭐ {name} (Best)' if name == best_model_name else name, 'value': name}
                            for name in all_models.keys()
                        ],
                        value=best_model_name,
                        clearable=False,
                        style={'borderRadius': '8px'},
                    ),
                ], md=4),
            ], className='mb-3'),

            dbc.Row([
                dbc.Col([
                    html.Label('🔢 Number of Questions', style={'fontWeight': '600', 'color': '#374151', 'marginBottom': '6px', 'display': 'block'}),
                    dcc.Slider(
                        id='n-slider',
                        min=1, max=50, step=1, value=5,
                        marks={i: str(i) for i in [1, 10, 20, 30, 40, 50]},
                        tooltip={'placement': 'bottom', 'always_visible': True},
                    ),
                ], md=12),
            ], className='mb-3'),

            dbc.Row([
                dbc.Col([
                    dbc.Checklist(
                        id='toggles',
                        options=[
                            {'label': ' Show Correct Answers', 'value': 'show_answers'},
                            {'label': ' Show Model Prediction', 'value': 'show_prediction'},
                        ],
                        value=[],
                        switch=True,
                        inline=True,
                        style={'fontWeight': '600', 'color': '#374151'},
                    ),
                ], md=7),

                dbc.Col([
                    dbc.Button(
                        '⚡ Generate Questions',
                        id='generate-btn',
                        color='primary',
                        size='lg',
                        className='w-100',
                        style={
                            'borderRadius': '10px',
                            'fontWeight': '700',
                            'background': 'linear-gradient(135deg, #1e40af, #3b82f6)',
                            'border': 'none',
                        }
                    ),
                ], md=5),
            ]),
        ])
    ], style={
        'border': '1px solid #e2e8f0',
        'borderRadius': '14px',
        'boxShadow': '0 2px 8px rgba(0,0,0,0.08)',
        'marginBottom': '24px',
    }),

    # ── Model Info Banner ─────────────────────────────────────────────────────
    html.Div(id='model-info-banner', style={'marginBottom': '16px'}),

    # ── Stats Row ─────────────────────────────────────────────────────────────
    html.Div(id='stats-row', style={'marginBottom': '16px'}),

    # ── Prediction Accuracy Summary (shown after generation) ──────────────────
    html.Div(id='prediction-summary', style={'marginBottom': '16px'}),

    # ── MCQ Output ────────────────────────────────────────────────────────────
    html.Div(id='mcq-output'),

], fluid=True, style={'maxWidth': '980px', 'fontFamily': 'Inter, Segoe UI, sans-serif'})


# ── Callbacks ─────────────────────────────────────────────────────────────────

# Cascade subject → topic
@app.callback(
    Output('topic-dropdown', 'options'),
    Output('topic-dropdown', 'value'),
    Input('subject-dropdown', 'value'),
)
def update_topics(selected_subject):
    if selected_subject == ALL or not selected_subject:
        filtered = topics
    else:
        filtered = sorted(
            df[df['subject_name'] == selected_subject]['topic_name'].unique().tolist()
        )
    opts = [{'label': t, 'value': t} for t in [ALL] + filtered]
    return opts, ALL


# Model info banner
@app.callback(
    Output('model-info-banner', 'children'),
    Input('model-dropdown', 'value'),
)
def update_model_banner(selected_model):
    descriptions = {
        'Logistic Regression': ('📐', '#eff6ff', '#1e40af', '#bfdbfe',
                                'Finds a linear boundary in TF-IDF feature space. Fast, interpretable, solid baseline.'),
        'Naive Bayes':         ('📊', '#f0fdf4', '#065f46', '#a7f3d0',
                                'Probabilistic classifier using word frequency. Very fast, works well on text.'),
        'Linear SVM':          ('⚙️', '#fdf4ff', '#6b21a8', '#e9d5ff',
                                'Maximises margin between classes in high-dimensional TF-IDF space. Often best on text.'),
    }
    icon, bg, color, border, desc = descriptions.get(
        selected_model,
        ('🤖', '#f8fafc', '#374151', '#e2e8f0', selected_model)
    )
    is_best = selected_model == best_model_name
    return dbc.Alert([
        html.Span(f'{icon} ', style={'fontSize': '18px'}),
        html.Strong(f'{selected_model}  '),
        html.Span('⭐ Best Model  ', style={'color': '#d97706', 'fontWeight': '700'}) if is_best else html.Span(),
        html.Span(desc, style={'color': color, 'fontSize': '13px'}),
    ], style={
        'background': bg,
        'border': f'1px solid {border}',
        'color': color,
        'borderRadius': '10px',
        'padding': '10px 16px',
    })


# Generate questions
@app.callback(
    Output('mcq-output', 'children'),
    Output('stats-row', 'children'),
    Output('prediction-summary', 'children'),
    Input('generate-btn', 'n_clicks'),
    State('subject-dropdown', 'value'),
    State('topic-dropdown', 'value'),
    State('n-slider', 'value'),
    State('toggles', 'value'),
    State('model-dropdown', 'value'),
    prevent_initial_call=True,
)
def generate_questions(n_clicks, subject, topic, n_questions, toggles, selected_model):
    toggles        = toggles or []
    show_answers   = 'show_answers'   in toggles
    show_prediction = 'show_prediction' in toggles

    # Filter dataset
    subset = df.copy()
    if subject and subject != ALL:
        subset = subset[subset['subject_name'] == subject]
    if topic and topic != ALL:
        subset = subset[subset['topic_name'] == topic]

    if subset.empty:
        return (
            dbc.Alert('⚠️ No questions found for this filter. Try a different Subject or Topic.',
                      color='warning', style={'borderRadius': '10px'}),
            html.Div(),
            html.Div()
        )

    n       = min(n_questions, len(subset))
    sampled = subset.sample(n=n, random_state=random.randint(0, 99999))

    # ── Stats bar ─────────────────────────────────────────────────────────────
    stat_style = {'textAlign': 'center', 'borderRadius': '10px', 'padding': '0'}
    stats = dbc.Row([
        dbc.Col(dbc.Card(dbc.CardBody([
            html.H4(str(n), style={'color': '#1e40af', 'margin': 0, 'fontWeight': '800'}),
            html.Small('Generated', style={'color': '#64748b'}),
        ]), style={**stat_style, 'border': '1px solid #bfdbfe'}), md=2),

        dbc.Col(dbc.Card(dbc.CardBody([
            html.H4(str(len(subset)), style={'color': '#7c3aed', 'margin': 0, 'fontWeight': '800'}),
            html.Small('Available', style={'color': '#64748b'}),
        ]), style={**stat_style, 'border': '1px solid #ddd6fe'}), md=2),

        dbc.Col(dbc.Card(dbc.CardBody([
            html.H4(subject if subject != ALL else 'All', style={
                'color': '#065f46', 'margin': 0, 'fontWeight': '700', 'fontSize': '13px'
            }),
            html.Small('Subject', style={'color': '#64748b'}),
        ]), style={**stat_style, 'border': '1px solid #a7f3d0'}), md=4),

        dbc.Col(dbc.Card(dbc.CardBody([
            html.H4(topic if topic != ALL else 'All', style={
                'color': '#92400e', 'margin': 0, 'fontWeight': '700', 'fontSize': '13px'
            }),
            html.Small('Topic', style={'color': '#64748b'}),
        ]), style={**stat_style, 'border': '1px solid #fde68a'}), md=4),
    ], className='g-2')

    # ── Build MCQ cards ───────────────────────────────────────────────────────
    cards = []
    correct_preds = 0

    for i, (_, row) in enumerate(sampled.iterrows(), start=1):
        if show_prediction:
            predicted = predict_answer(row['question'], selected_model)
            if predicted == row.get('correct_label', ''):
                correct_preds += 1
        cards.append(make_mcq_card(i, row, show_answers, show_prediction, selected_model))

    # ── Prediction accuracy summary banner ───────────────────────────────────
    pred_summary = html.Div()
    if show_prediction:
        accuracy = round((correct_preds / n) * 100, 1)
        color    = '#d1fae5' if accuracy >= 70 else '#fef9c3' if accuracy >= 50 else '#fee2e2'
        border   = '#10b981' if accuracy >= 70 else '#f59e0b' if accuracy >= 50 else '#ef4444'
        txt_col  = '#065f46' if accuracy >= 70 else '#92400e' if accuracy >= 50 else '#991b1b'
        emoji    = '🟢' if accuracy >= 70 else '🟡' if accuracy >= 50 else '🔴'

        pred_summary = dbc.Alert([
            html.Strong(f'{emoji} Model Prediction Accuracy on this batch: '),
            html.Span(f'{correct_preds}/{n} correct  ({accuracy}%)',
                      style={'fontWeight': '700', 'fontSize': '15px'}),
            html.Span(f'  using {selected_model}',
                      style={'fontSize': '12px', 'color': txt_col, 'marginLeft': '8px'}),
        ], style={
            'background': color,
            'border': f'1px solid {border}',
            'color': txt_col,
            'borderRadius': '10px',
            'padding': '10px 16px',
        })

    return html.Div(cards), stats, pred_summary


if __name__ == '__main__':
    app.run(debug=True, port=8050)